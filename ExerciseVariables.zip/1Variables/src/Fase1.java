
public class Fase1 {

	public static void main(String[] args) {

		String nom = "Ilaria";
		String cognom1 = "Boselli";
		String cognom2 = "-";
		int dia = 10;
		int mes = 11;
		int any = 1977;
		System.out.println(cognom1 + " " + cognom2 + " " + nom);
		System.out.println(dia + "/" + mes + "/" + any);
	}
}
