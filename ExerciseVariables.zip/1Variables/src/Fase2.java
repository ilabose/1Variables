
public class Fase2 {

	public static void main(String[] args) {
		final double bisesto = 1948;
        double traspas = 4;
        double diferencia = ((1977 - bisesto) / traspas);
        System.out.println(diferencia);
	}

}
