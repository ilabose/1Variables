
public class Fase4 {

	public static void main(String[] args) {
		String name =  "Ilaria Boselli";
		System.out.println("El meu nom �s " + name);
		String cumple = "10/11/1977";
		System.out.println("Vaig n�ixer el " + cumple);
		System.out.println("El meu any de naixement no �s de trasp�s");
		

	}

}
